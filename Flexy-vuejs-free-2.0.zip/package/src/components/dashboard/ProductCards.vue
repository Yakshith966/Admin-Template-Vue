<script setup lang="ts"></script>

<template>
  <v-row>
    <v-col cols="12" lg="4">
      <v-card elevation="10">
        <img
          style="width: 100%"
          src="@/assets/images/background/u1.jpg"
        />
        <v-card-text>
          <h5 class="title font-weight-medium mb-2 text-h6">
            Super awesome, Vue 3 is coming soon!
          </h5>
          <p class="mb-3 text-body-2 text-grey-darken-1">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <v-btn flat color="warning">Learn More</v-btn>
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="12" lg="4">
      <v-card elevation="10">
        <img
          style="width: 100%"
          src="@/assets/images/background/u2.jpg"
        />
        <v-card-text>
          <h5 class="title font-weight-medium mb-2 text-h6">
            Super awesome, Vue 3 is coming soon!
          </h5>
          <p class="mb-3 text-body-2 text-grey-darken-1">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <v-btn flat color="error">Learn More</v-btn>
        </v-card-text>
      </v-card>
    </v-col>
    <v-col cols="12" lg="4">
      <v-card elevation="10">
        <img
          style="width: 100%"
          src="@/assets/images/background/u3.jpg"
        />
        <v-card-text>
          <h5 class="title font-weight-medium mb-2 text-h6">
            Super awesome, Vue 3 is coming soon!
          </h5>
          <p class="mb-3 text-body-2 text-grey-darken-1">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <v-btn flat color="info">Learn More</v-btn>
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>
