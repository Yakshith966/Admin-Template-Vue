<template>
    <div class="bg-lightsecondary pa-6 rounded-md position-relative">
        <div class="position-relative z-1">
            <h5 class="text-h5 font-weight-semibold">Check Pro
                </h5>
            <h5 class="text-h5 font-weight-semibold">Version</h5>
            <v-btn color="secondary" flat class="mt-3" href="https://www.wrappixel.com/templates/flexy-vuetify-dashboard/?ref=376#demos" target="_blank">check</v-btn>
        </div>
        <img src="@/assets/images/background/sidebar-buynow.png" alt="upgrade" class="position-absolute rtlImg top-0 mt-n6 right-0" />
    </div>
</template>
